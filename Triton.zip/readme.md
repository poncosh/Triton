# TRITON.

For using this app, please download dependencies in package.json.

Build in webpack, babel and bootstrap. This app is using TMDB database source for API.
Triton is a web movies app for film lovers out there.

There's a bug on webpack devServe on continuous scroll button. This resolved by bundling it into dist

![Triton App](./Triton.jpg)